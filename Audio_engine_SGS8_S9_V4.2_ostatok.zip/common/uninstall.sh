#!/sbin/sh

TMPDIR=/dev/tmp

# Load config script
. $TMPDIR/config.sh

app="SapaAudioConnectionService
SapaMonitor
SplitSoundService
";
bin="apaservice
apexserver
auditd
jackd
jackservice
profman
samsungpowersoundplay
media
";
etc="apa_settings.cfg
audio_effects.conf
certReqTemplate128.der
certReqTemplate256.der
floating_feature.xml
jack_alsa_mixer.json
mixer_gains.xml
mixer_gains_r00.xml
mixer_paths_r00.xml
mixer_paths_r01.xml
sapa_feature.xml
SoundAlive_Settings.xml
stage_policy.conf
feature_default.xml
soundalive
";
etccacerts="262ba90f.0
b936d1c6.0
31188b5e.0
c2c1704e.0
33ee480d.0
c907e29b.0
583d0756.0
cb1c3204.0
7892ad52.0
d0cddf45.0
7a7c655d.0
d41b5e2a.0
7c302982.0
d5727d6a.0
88950faa.0
dfc0fe80.0
a81e292b.0
fb5fa911.0
ab59055e.0
fd08c599.0
";
permissions="com.google.android.media.effects.xml
com.samsung.device.xml
com.sec.android.app.minimode.xml
com.sec.android.app.multiwindow.xml
com.sec.android.visualeffect.xml
semextendedformat.xml
SemAudioThumbnail_library.xml
privapp-permissions-com.sec.android.app.soundalive.xml
platform.xml
com.samsung.feature.device_category_phone_high_end.xml
com.samsung.feature.device_category_phone.xml
android.hardware.audio.pro.xml
android.hardware.audio.low_latency.xml
";
framework="SecProductFeature_AUDIO.jar
SemAudioThumbnail.jar
codecsolution.jar
com.google.android.media.effects.jar
com.samsung.device.jar
com.sec.android.app.minimode.jar
com.sec.android.app.multiwindow.jar
com.sec.android.visualeffect.jar
hqm.jar
samsung-services.jar
semextendedformat.jar
media_cmd.jar
";
lib="android.hardware.audio.common@2.0-util.so
android.hardware.audio.common@2.0.so
android.hardware.audio.effect@2.0.so
android.hardware.audio@2.0.so
android.hardware.soundtrigger@2.0.so
jack
libSoundAlive_VSP_ver315b_arm.so
lib_DNSe_EP_ver216c.so
lib_SA_GoogleFX_ver124b.so
lib_SamsungVAD_v01009.so
lib_SoundAlive_AlbumArt_ver105.so
lib_SoundAlive_SRC384_ver320.so
lib_SoundAlive_play_plus_ver210.so
lib_SoundBooster_ver900.so
lib_soundaliveresampler.so
libapa.so
libapa_client.so
libapa_control.so
libapaproxy.so
libapex.so
libapex_client.so
libapex_cmn.so
libapex_intf.so
libaudiosaplus_sec_legacy.so
libcodecsolution.so
libcorefx.so
libfloatingfeature.so
libhiddensound.so
libjackserver.so
libjackservice.so
libjackshm.so
libmediacapture.so
libmediacapture_jni.so
libmediacaptureservice.so
libmysound_legacy.so
libsamsungDiamondVoice.so
libsamsungSoundbooster_plus_legacy.so
libsamsungearcare.so
libsamsungeffect.so
libsamsungvad.so
libsavsac.so
libsavscmn.so
libsavsff.so
libsavsmeta.so
libsavsvc.so
libsvoicedll.so
libswdap_legacy.so
libwebrtc_audio_preprocessing.so
libdexfile.so
soundfx
libasound.so
libsamsungpowersound.so
libsoundextractor.so
libsoundspeed.so
libaaudio.so
libaudiohal.so
liblegacyeffects.so
libspeexresampler.so
libsonic.so
libsonivox.so
";
lib64="android.hardware.audio.common@2.0-util.so
android.hardware.audio.common@2.0.so
android.hardware.audio.effect@2.0.so
android.hardware.audio@2.0.so
android.hardware.soundtrigger@2.0.so
libSamsungAPVoiceEngine.so
libSoundAlive_SRC192_ver205a.so
libSoundAlive_VSP_ver316a_ARMCpp_64bit.so
lib_DNSe_EP_ver216c.so
lib_SoundAlive_SRC384_ver320.so
lib_soundaliveresampler.so
libapa.so
libapa_client.so
libapa_control.so
libapaproxy.so
libapex_client.so
libapex_cmn.so
libapex_intf.so
libcodecsolution.so
libfloatingfeature.so
libhiddensound.so
libjackshm.so
libmediacapture.so
libmediacapture_jni.so
libsamsungearcare.so
libsamsungeffect.so
libsavsac.so
libsavscmn.so
libsavsff.so
libsavsmeta.so
libsavsvc.so
libscore.so
libswdap_legacy.so
libwebrtc_audio_preprocessing.so
libdexfile.so
soundfx
libaaudio.so
libaudioclient.so
libaudiohal.so
libsoundextractor.so
liblegacyeffects.so
libspeexresampler.so
libsonic.so
libsonivox.so
";
privapp="SoundAlive_54
";
vendoretc="SoundBoosterParam.txt
audio_effects.conf
audio_effects.xml
permissions
";
vendorfirmware="APBargeIn_AUDIO_SLSI.bin
APBiBF_AUDIO_SLSI.bin
APDV_AUDIO_SLSI.bin
AP_AUDIO_SLSI.bin
SoundBoosterParam.bin
dsm.bin
dsm_tune.bin
vts.bin
";
vendorlib="libSamsungPostProcessConvertor.so
lib_SamsungRec_06006.so
lib_SoundAlive_3DPosition_ver202.so
lib_SoundAlive_AlbumArt_ver105.so
lib_SoundAlive_SRC384_ver320.so
lib_SoundAlive_play_plus_ver210.so
lib_SoundBooster_ver900.so
lib_soundaliveresampler.so
libaboxpcmdump.so
libapa_jni.so
libapex_jni.so
libaudiohookclient.so
libcodecdspdump.so
libcordon.so
libfloatingfeature.so
libjack.so
librecordalive.so
libsmart_cropping.so
libwebrtc_audio_preprocessing.so
soundfx
";
vendorlib64="libapa_jni.so
libapex_jni.so
libaudiohookclient.so
libcordon.so
libfloatingfeature.so
libjack.so
libsmart_cropping.so
libwebrtc_audio_preprocessing.so
soundfx
";
xbin="jack_connect
jack_disconnect
jack_lsp
jack_showtime
jack_simple_client
jack_transport
";
property="persist.audio.a2dp_avc
persist.audio.allsoundmute
persist.audio.corefx
persist.audio.effectcpufreq
persist.audio.finemediavolume
persist.audio.globaleffect
persist.audio.headsetsysvolume
persist.audio.hphonesysvolume
persist.audio.k2hd
persist.audio.mpseek
persist.audio.mysound
persist.audio.nxp_lvvil
persist.audio.pcmdump
persist.audio.ringermode
persist.audio.sales_code
persist.audio.soundalivefxsec
persist.audio.stereospeaker
persist.audio.sysvolume
persist.audio.uhqa
persist.audio.voipcpufreq
persist.bluetooth.enableinbandringing
";

uninstall() {
  for F_APP in $app; do
    rm -rf $APP/$F_APP
  done
  for F_BIN in $bin; do
    rm -rf $BIN/$F_BIN
  done
  for F_ETC in $etc; do
    rm -rf $ETC/$F_ETC
  done
  rm -rf $ETC/SoundAlive_Settings.xml
  rm -rf $ETC/soundalive
  rm -rf $ETC/init/powersnd.rc
  rm -rf $ETC/firmware/cs47l92-dsp1-dsd-176.4kHz.wmfw
  rm -rf $ETC/firmware/cs47l92-dsp1-dsd-352.8kHz.wmfw
  rm -rf $ETC/firmware/cs47l92-dsp1-trace.wmfw
  for F_CACERTS in $etccacerts; do
    rm -rf $ETC/security/cacerts/$F_CACERTS
  done
  rm -rf $ETC/security/cacerts_wfa
  for F_PERMISSIONS in $permissions; do
    rm -rf $ETC/permissions/$F_PERMISSIONS
  done
  rm -rf $ETC/init/powersnd.rc
  for F_FRAMEWORK in $framework; do
    rm -rf $FRAME/$F_FRAMEWORK
  done
  for F_LIB in $lib; do
    rm -rf $LIB/$F_LIB
  done
  rm -rf $LIB/hw/audio*
  rm -rf $LIB/hw/sound_trigger*
  for F_PRIVAPP in $privapp; do
    rm -rf $PRIV/$F_PRIVAPP
  done
  for F_XBIN in $xbin; do
    rm -rf $XBIN/$F_XBIN
  done
  for F_VENDORETC in $vendoretc; do
    rm -rf $ETC_VE/$F_VENDORETC
  done
  for F_VENDORFIRMWARE in $vendorfirmware; do
    rm -rf $VENDOR/firmware/$F_VENDORFIRMWARE
  done
  for F_VENDORLIB in $vendorlib; do
    rm -rf $LIB_VE/$F_VENDORLIB
  done
  rm -rf $LIB_VE/hw/audio*
  rm -rf $LIB_VE/hw/android.hardware.audio*
  rm -rf $LIB_VE/hw/android.hardware.soundtrigger*
  if find $LIB_VE/hw/* ; then echo "" > /dev/null; else
	rm -rf $LIB_VE/hw
  fi
  if [ -f $SYS/bin/app_process64 ]; then
    for F_LIB64 in $lib64; do
      rm -rf $LIB64/$F_LIB64
    done
	rm -rf $LIB64/hw/audio*
	rm -rf $LIB64/hw/sound_trigger*
    for F_VENDORLIB64 in $vendorlib64; do
      rm -rf $LIB64_VE/$F_VENDORLIB64
    done
    rm -rf $LIB64_VE/hw/audio*
    rm -rf $LIB64_VE/hw/android.hardware.audio*
    if find $LIB64_VE/hw/* ; then echo "" > /dev/null; else
	  rm -rf $LIB64_VE/hw
    fi
  fi
  rm -rf $USR/share/alsa
  rm -rf $DATA_M/jack
  rm -rf $DATA_M/profman
  for F_PROPERTY in $property; do
    rm -rf $PROPERTY/$F_PROPERTY
  done
  rm -rf $DATA/data/com.samsung.android.sdk.professionalaudio.app.audioconnectionservice
  rm -rf $DATA/data/com.samsung.android.sdk.professionalaudio.utility.jammonitor
  rm -rf $DATA/data/com.sec.android.splitsound
  rm -rf $DATA/data/com.sec.android.app.soundalive
  rm -rf $DATA/dalvik-cache/arm*/*SapaAudioConnectionService*
  rm -rf $DATA/dalvik-cache/arm*/*SapaMonitor*
  rm -rf $DATA/dalvik-cache/arm*/*SplitSoundService*
  rm -rf $DATA/dalvik-cache/arm*/*SoundAlive_54*
}

uninstall; tar -xf $BK -C $SYS
rm -rf $BK
