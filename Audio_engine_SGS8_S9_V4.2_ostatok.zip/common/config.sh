SYS=/system APP=$SYS/app BIN=$SYS/bin ETC=$SYS/etc FRAME=$SYS/framework LIB=$SYS/lib LIB64=$SYS/lib64 PRIV=$SYS/priv-app USR=$SYS/usr XBIN=$SYS/xbin BUILD=$SYS/build.prop
VENDOR=$SYS/vendor ETC_VE=$VENDOR/etc LIB_VE=$VENDOR/lib LIB64_VE=$VENDOR/lib64 BUILD_VE=$VENDOR/build.prop
DATA=/data DATA_M=$DATA/misc LOCAL=$DATA/local PROPERTY=$DATA/property rwrr='chmod 0644' rwxrxrx='chmod 0755' SPECIFIC=$TMPDIR/specific
NAMEBK=engine_sv4_b42.dub
ENGINE_SV=$SYS/engine_sv BK=$LOCAL/$NAMEBK
# Configuration and variables